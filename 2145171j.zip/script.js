"use strict";

// EPEG.js start

function tokenize(input, gram) {
  if(typeof input !== "string") {
    throw new Error("Input is not a string");
  }
  var keys = gram.tokenKeys;
  var tokens = gram.tokenMap;
  var stream = [];
  var len = input.length, candidate, i, key, copy = input, lastToken = null;
  var pointer = 0;
  var line = 0;
  var column = 0;

  while(pointer < len) {
    candidate = null;
    for(i=0; i<keys.length; i++) {
      key = keys[i];
      var token = tokens[key], match;
      if(token.func) {
        match = token.func(input, stream);
        if(match !== undefined) {
          candidate = match;
          break;
        }
      } else if(token.reg) {
        match = input.match(token.reg);
        if(match !== null) {
          candidate = match[0];
          break;
        }
      } else if(token.str) {
        match = input.indexOf(token.str);
        if(match === 0) {
          candidate = token.str;
          break;
        }
      } else {
        throw new Error("Tokenizer error: Invalid token " + key + " without a reg, str or func property");
      }
    }
    if(candidate !== null) {
      lastToken = {type:key, value:candidate, pointer:pointer, line:line+1, column:column+1};
      stream.push(lastToken);
      var line_breaks_count = countLineBreak(candidate);
      line += line_breaks_count;
      if(line_breaks_count > 0) {
        column = 0;
      }
      column += countColumn(candidate);
      pointer += candidate.length;
      input = input.substr(candidate.length);
    } else {
      if(stream.length === 0) {
        throw new Error("Tokenizer error: total match failure");
      }
      if(lastToken)
        lastToken.pointer += lastToken.value.length;
      var msg = errorMsg(copy, stream[stream.length - 1], "Tokenizer error", "No matching token found");
      if(lastToken)
        msg += "\n" + "Before token of type " + lastToken.type + ": " + lastToken.value;
      throw new Error(msg);
    }
  }
  stream.push({type:'EOF', value:""});
  return stream;
}

function countLineBreak(str) {
  var m = str.split(/\n/g);
  return m.length - 1;
}

function countColumn(str) {
  var m = str.split(/\n/g);
  return m[m.length-1].length;
}

function copyToken(stoken, rtoken) {
  var t = {
    type:stoken.type,
    value:stoken.value,
    repeat:rtoken.repeat,
    line:stoken.line,
    column:stoken.column
  };
  if(rtoken.name) {
    t.name = rtoken.name;
  }
  return t;
}

function createParams(tokens) {
  var params = {};
  var j = 0;
  tokens.map(function(i) {
    if(i.name) {
      if(i.repeat == '*' || i.repeat == '+') {
        if(!params[i.name]) {
          params[i.name] = [];
        }
        params[i.name].push(i);
      } else {
        params[i.name] = i;
      }
    }
    params['$'+j] = i;
    j++;
  });
  return params;
}

function growLR(grammar, rule, stream, pos, memo) {
  var sp, result, progress = false;
  var hook = grammar[rule.key].hooks[rule.index];

  while(true) {
    sp = pos;

    result = evalRuleBody(grammar, rule, stream, sp);

    // ensure some progress is made
    if(result === false || result.sp <= memo.sp) {
      return progress;
    }

    result.hook = hook;

    // it's very important to update the memoized value
    // this is actually growing the seed in the memoization
    memo.children = result.children;
    memo.sp = result.sp;
    memo.line = result.line;
    memo.column = result.column;
    memo.start = result.start;
    memo.hooked = result.hooked;
    memo.hook = result.hook;
    progress = result;
  }
  return progress;
}

function memoEval(grammar, rule, stream, pointer) {

  var key = rule.key+';'+pointer+';'+rule.index;

  // avoid infinite recursion
  // This is faster than filter
  var i = stack.length - 1;
  while(i >= 0) {
    if(stack[i][0] == key) {
      return false;
    }
    i = i-1;
  }

  var memo_entry = memoization[rule.key+';'+pointer];
  if(memo_entry !== undefined) {
    return memo_entry;
  }

  stack.push([key, rule]);
  var result = evalRuleBody(grammar, rule, stream, pointer);
  stack.pop();

  return result;
}

function canFail(token, node) {
  if(token.repeat === '*' || token.repeat === '?') {
    return true;
  }
  if(token.repeat === '+' && node.children.length && node.children[node.children.length - 1].type == token.type) {
    return true;
  }
  return false;
}

function canRepeat(token) {
  return token.repeat === '*' || token.repeat === '+';
}

function evalRuleBody(grammar, rule, stream, pointer) {

  var sp = pointer; // stream pointer
  var rp = 0;       // rule pointer
  var j, result;

  var rtoken = rule.tokens[rp];
  var stoken = stream[sp];

  var currentNode = {
    type: rule.key, 
    children:[], 
    start:pointer, 
    name:rule.name, 
    line:stoken.line, 
    column:stoken.column
  };

  while(rtoken && stoken) {

    // Case one: we have a rule we need to develop
    if(grammar[rtoken.type]) {

      var expand_rules = grammar[rtoken.type].rules;
      var hooks = grammar[rtoken.type].hooks;
      result = false;

      var m = memoization[rtoken.type+';'+sp];
      if(m) {
        result = m;
      }

      if(!result) {
        for(j=0; j<expand_rules.length; j++) {
          var r = expand_rules[j], hook = hooks[j];

          result = memoEval(grammar, r, stream, sp);

          if(result) {

            result.hook = hook;

            memoization[r.key+';'+sp] = result;

            if(rtoken.repeat === false) {
              var n_result = growLR(grammar, rule, stream, sp, result);
              if(n_result !== false) {
                return n_result;
              }
            }
            break;
          }
        }
      }

      if(result) {
        sp = result.sp;
        currentNode.children.push({
            type: rtoken.type,
            children: result.children,
            sp:result.sp,
            line: result.line,
            column: result.column,
            hook: result.hook,
            name: rtoken.name,
            repeat: rtoken.repeat
          });
        if(!canRepeat(rtoken)) {
          rp++;
        }
      } else {
        if(!canFail(rtoken, currentNode)) {
          return false;
        }
        rp++;
      }

    // Case two: we have a proper token
    } else {
      if(stoken.type === rtoken.type) {
        //currentNode.children.push(copyToken(stoken, rtoken));
        if(!rtoken.nonCapturing) {
          currentNode.children.push(copyToken(stoken, rtoken));
          sp++;
        }
        if(!canRepeat(rtoken)) {
          rp++;
        }
      } else {
        if(!canFail(rtoken, currentNode)) {
          return false;
        }
        rp++;
      }

    }

    // information used for debugging purpose
    if(best_p === sp) {
      best_parse.candidates.push([rule, rule.tokens[rp]]);
    }
    if(best_p < sp) {
      best_parse = {sp:sp, candidates:[[rule, rule.tokens[rp]]]};
      best_p = sp;
    }

    // fetch next rule and stream token
    rtoken = rule.tokens[rp];
    stoken = stream[sp];

    // rule satisfied
    if(rtoken === undefined) {
      currentNode.sp = sp;
      currentNode.rp = rp;
      return currentNode;
    }

    // no more tokens
    if(stoken === undefined) {
      if(canFail(rtoken, currentNode)) {
        // This does not happen often because of EOF,
        // As it stands the last token as always to be EOF
        currentNode.sp = sp;
        currentNode.rp = rp;
        return currentNode;
      }
      return false;
    }

  } // end rule body loop

  return false;
}

function splitTrim(l, split) {
  return l.split(split).map(function(i){ return i.trim(); });
}

function grammarToken(token) {
  var nonCapturing = token.charAt(0) === '!';
  if(nonCapturing) {
    token = token.substr(1);
  }
  var repeat = token.charAt(token.length - 1);
  if(repeat === '*' || repeat === '?' || repeat === '+') {
    token = token.substr(0, token.length - 1);
  } else {
    repeat = false;
  }
  var named = token.split(":"), t;
  if(named.length === 2) {
    t = {
      'type': named[1],
      'name' :named[0]
    };
  } else {
    t = {'type': token };
  }
  t.repeat = repeat;
  if((repeat === '*' || repeat === '+') && nonCapturing) {
    throw new Error("Impossible to have non capturing token that repeats");
  }
  if(nonCapturing) {
    t.nonCapturing = nonCapturing;
  }
  return t;
}

function compileGrammar(grammar, tokenDef) {
  var keys = Object.keys(grammar), i, j, k;
  var gram = {}, optional, nonCapturing;

  gram.tokenDef = tokenDef;
  gram.tokenKeys = [];
  gram.tokenMap = {};
  tokenDef.map(function(t) {
    gram.tokenMap[t.key] = t;
    gram.tokenKeys.push(t.key);
  });

  var allValidKeys = keys.concat(gram.tokenKeys);

  for(i=0; i<keys.length; i++) {
    var line = grammar[keys[i]];
    var key = keys[i];
    var rules = line.rules;
    var hooks = [];

    var splitted_rules = [];

    for(j=0; j<rules.length; j++) {
      var tokens = splitTrim(rules[j], ' ');
      optional = 0;
      for(k=0; k<tokens.length; k++) {
        var token = tokens[k] = grammarToken(tokens[k]);
        if(allValidKeys.indexOf(token.type) === -1 && token.type !== 'EOF') {
          throw new Error("Invalid token type used in the grammar rule "+key+": " + token.type + ', valid tokens are: '+allValidKeys.join(', '));
        }
        if(token.repeat === '*') {
          optional += 1;
        }
        if(token.nonCapturing) {
          if(tokens[tokens.length - 1] != tokens[k]) {
            throw new Error("A non capturing token can only be the last one in the rule: " + token.type);
          }
        }
      }
      if(optional === tokens.length) {
        throw new Error("Rule " + rules[j] + " only has optional greedy tokens.");
      }
      splitted_rules.push({key: key, index:j, tokens:tokens});
      if(typeof line.hooks === "function") {
        hooks.push(line.hooks);
      } else if(line.hooks) {
        if(line.hooks[j] === undefined) {
          throw new Error("Incorrect number of hooks ar rule " + keys[i]); 
        }
        hooks.push(line.hooks[j]);
      }
    }
    gram[key] = {rules: splitted_rules, hooks: hooks || [], verbose:line.verbose};
  }
  gram.parse = function parseWithGrammar(stream) {
    return parse(stream, gram);
  };
  return gram;
}

function spacer(n) {
  var out = "";
  for(var i=0; i<n; i++) {
    out += " ";
  }
  return out;
}

function errorMsg(input, token, errorType, m) {

  var charn = (token && token.pointer) || 0;
  var lines = input.split("\n"), i, charCounter = 0, charOnLine = 0;

  for(i=0; i<lines.length; i++) {
    charCounter += lines[i].length + 1;
    if(charCounter >= charn) {
      break;
    }
    charOnLine += lines[i].length + 1;
  }

  var ln = Math.max(0, i); // line number
  var msg = errorType + " at line "+(ln+1)+" char "+ (charn - charOnLine) +": ";
  var indicator = "\n" + spacer((charn - charOnLine) + ((ln) + ': ').length);

  if(lines[ln-1] !== undefined) {
    msg = msg + "\n" + (ln) + ': ' + lines[ln-1];
  }
  msg = msg + "\n" + (ln+1) + ': ' + lines[ln] + indicator;
  msg = msg + "^-- " + m;

  if(lines[ln+1] !== undefined) {
    msg = msg + "\n" + (ln+2) + ': ' + lines[ln+1];
  }

  return msg;
}

function verboseName(grammar, type) {
  var tokendef = grammar.tokenMap[type];
  if(tokendef && tokendef.verbose) {
    return tokendef.verbose;
  }
  if(grammar[type] && grammar[type].verbose) {
    return grammar[type].verbose;
  }
  return type;
}

function hint(input, stream, best_parse, grammar) {
  if(!best_parse || !best_parse.candidates[0]) {
    return "Complete failure to parse";
  }
  var rule = best_parse.candidates[0][0];

  var array = [];
  best_parse.candidates.map(function(r) {
    if(!r[1]) { return; }
    var name = verboseName(grammar, r[1].type);
    if(array.indexOf(name) === -1) {
      array.push(name);
    }
  });
  var candidates = array.join(' or ');

  var msg = errorMsg(input, stream[best_parse.sp], "Parser error", "Rule " + verboseName(grammar, rule.key));
  msg = msg + "\nExpect " + candidates;
  var lastToken = stream[best_parse.sp] || {type:"EOF"};
  msg = msg + "\nBut got " + verboseName(grammar, lastToken.type) + " instead";

  return msg;
}

// those are module globals
var stack = [];
var memoization = {};
var best_parse = null;
var best_p = 0;

function hookTree(node) {
  if(!node.children) {
    return;
  }
  for(var i=0; i<node.children.length; i++) {
    hookTree(node.children[i]);
  }
  if(node.hook) {
    node.children = node.hook(createParams(node.children));
  }
}

function parse(input, grammar) {
  var bestResult = {type:'START', sp:0, complete:false}, i, result, stream;
  stream = tokenize(input, grammar);
  best_parse = {sp:0, candidates:[]};
  best_p = 0;
  for(i=0; i<grammar.START.rules.length; i++) {
    stack = [];
    memoization = {};
    result = memoEval(grammar, grammar.START.rules[i], stream, 0);
    if(result && result.sp > bestResult.sp) {
      bestResult = {
        type:'START',
        children:result.children,
        hook: grammar.START.hooks[i],
        sp: result.sp,
        line: 1,
        column: 1,
        complete:result.sp === stream.length,
        inputLength:stream.length,
      };
    }
  }
  bestResult.bestParse = best_parse;
  hookTree(bestResult);
  if(best_parse && !bestResult.complete) {
    bestResult.hint = hint(input, stream, best_parse, grammar);
  }
  return bestResult;
}

var tokensDef = [
    {key:"letter", reg:/^[a-z]/},
    {key:"op", reg:/^[∧|∨|→|↔]/},
    {key:"neg", reg:/^[¬]/},
    {key:"lb", reg:/^[(]/},
    {key:"rb", reg:/^[)]/},
];
  
var grammarDef = {
    "START": {rules: ["EXPR EOF"]},
    "EXPR": {rules: [
        "TERM op TERM",
        "neg TERM",
        "TERM"
    ]},
    "TERM": {rules: [
        "letter",
        "lb EXPR rb"
    ]}
};

var parser = compileGrammar(grammarDef, tokensDef);

function isValid(input) {
    var AST = parser.parse(input);
    return AST;
}

// EPEG.js end

// verifier

function removeProps(obj) {
  for(var prop in obj) {
    if (prop === 'sp' || prop === 'column')
      delete obj[prop];
    else if (typeof obj[prop] === 'object')
      removeProps(obj[prop]);
  }
}

function deepEqual(obj1, obj2) {
  removeProps(obj1);
  removeProps(obj2);
  var a = JSON.stringify(obj1)
  var b = JSON.stringify(obj2);
  return (a.split('').sort().join('') == b.split('').sort().join(''));
}

function checkRule(id, rule, data, children) {
  var childData = [];
  for (var i = 0; i < children.length; i++) {
      childData.push(children[i].data);
  }
  var valid = true;

  var inf = isValid(data);
  if (!inf.complete) {
    valid = false;
  }
  
  if(childData[0] != null) {
    var left = isValid(childData[0]);
    left = left.children[0]; //EXPR
    var leftterm, left1, leftop, left2;
    var leftneg = false;
    var left1neg = false;
    var left2neg = false;
    if (left.children.length == 1) { //TERM
      leftterm = left.children[0];
    } else if (left.children.length == 2) { //neg TERM
      leftneg = true;
      leftterm = left.children[1];
    } else if (left.children.length == 3) { //TERM op TERM
      left1 = left.children[0];
      leftop = left.children[1];
      left2 = left.children[2];
      if (left1.children.length > 1) {
        if (left1.children[1].children.length == 2) {
          left1neg = true;
          left1 = left1.children[1].children[1];
        }
      }
      if (left2.children.length > 1) {
        if (left2.children[1].children.length == 2) {
          left2neg = true;
          left2 = left2.children[1].children[1];
        }
      }
    }
    if(childData[1] != null) {
      var right = isValid(childData[1]);
      right = right.children[0]; //EXPR
      var rightterm, right1, rightop, right2;
      var rightneg = false;
      var right1neg = false;
      var right2neg = false;
      if (right.children.length == 1) { //TERM
        rightterm = right.children[0];
      } else if (right.children.length == 2) { //neg TERM
        rightneg = true;
        rightterm = right.children[1];
      } else if (right.children.length == 3) { //TERM op TERM
        right1 = right.children[0];
        rightop = right.children[1];
        right2 = right.children[2];
        if (right1.children.length > 1) {
          if (right1.children[1].children.length == 2) {
            right1neg = true;
            right1 = right1.children[1].children[1];
          }
        }
        if (right1.children.length > 1) {
          if (right2.children[1].children.length == 2) {
            right2neg = true;
            right2 = right2.children[1].children[1];
          }
        }
      }
    }

    if(valid) {
      inf = inf.children[0]; //EXPR
      var infterm, inf1, infop, inf2;
      var infneg = false;
      var inf1neg = false;
      var inf2neg = false;
      if (inf.children.length == 1) { //TERM
        infterm = inf.children[0];
      } else if (inf.children.length == 2) { //neg TERM
        infneg = true;
        infterm = inf.children[1];
      } else if (inf.children.length == 3) { //TERM op TERM
        inf1 = inf.children[0];
        infop = inf.children[1];
        inf2 = inf.children[2];
        if (inf1.children.length > 1) {
          if (inf1.children[1].children.length == 2) {
            inf1neg = true;
            inf1 = inf1.children[1].children[1];
          }
        }
        if (inf2.children.length > 1) {
          if (inf2.children[1].children.length == 2) {
            inf2neg = true;
            inf2 = inf2.children[1].children[1];
          }
        }
      }
      
      switch(rule) {
          case "mp":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if (leftop != null) {
                if(!(deepEqual(rightterm, left1) && leftop.value == "→" && deepEqual(left2, infterm))) {
                    valid = false;
                }
              }
              else if (rightop != null) {
                if(!(deepEqual(leftterm, right1) && rightop.value == "→" && deepEqual(right2, infterm))) {
                    valid = false;
                }
              }
              else {
                valid = false;
              }
              break;

          case "mt":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if (leftop != null) {
                if(!(deepEqual(rightterm, left2) && rightneg != left2neg && leftop.value == "→" && deepEqual(left1, infterm) && left1neg != infneg)) {
                    valid = false;
                }
              }
              else if (rightop != null) {
                if(!(deepEqual(leftterm, right2) && leftneg != right2neg && rightop.value == "→" && deepEqual(right1, infterm) && right1neg != infneg)) {
                    valid = false;
                }
              }
              else {
                valid = false;
              }
              break;

          case "co":
              if (childData.length != 1) {
                valid = false;
                break;
              }

              if (leftop != null && infop != null) {
                if(!(deepEqual(left1, inf2) && deepEqual(left2, inf1) && deepEqual(leftop, infop))) {
                  valid = false;
                }
              } else {
                valid = false;
              }
              break;

          case "bi":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if(!(deepEqual(left1, right2) && deepEqual(left2, right1) && ((deepEqual(left1, inf1) && deepEqual(left2, inf2))
                || (deepEqual(left1, inf2) && deepEqual(left2, inf1))) && leftop.value == "→" && rightop.value == "→" && infop.value == "↔")) {
                valid = false;
              }
              break;
          
          case "tr":
              if (childData.length != 1) {
                valid = false;
                break;
              }

              if(leftop != null && infop != null) {
                if(!(deepEqual(left1, inf2) && deepEqual(left2, inf1) && left1neg != inf2neg && left2neg != inf1neg)) {
                  valid = false;
                }
              } else {
                valid = false;
                break;
              }
              break;

          case "hs":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if(!(((deepEqual(left1, inf1) && deepEqual(left2, right1) && deepEqual(right2, inf2))
                || (deepEqual(right1, inf1) && deepEqual(right2, left1) && deepEqual(left2, inf2)))
                && leftop.value == "→" && rightop.value == "→" && infop.value == "→")) {
                valid = false;
              }
              break;

          case "mi":
              if (childData.length != 1) {
                valid = false;
                break;
              }

              if(leftop != null && infop != null) {
                if(!(deepEqual(left1, inf1) && deepEqual(left2, inf2) && left1neg != inf1neg && left2neg == inf2neg && leftop.value == "→" && infop.value == "∨")) {
                  valid = false;
                }
              } else {
                valid = false;
                break;
              }
              break;

          case "ds":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if (leftop != null) {
                if(!(((deepEqual(left1, rightterm) && left1neg != rightneg && deepEqual(left2, infterm) && left2neg == infneg)
                  || (deepEqual(left2, rightterm) && left2neg != rightneg && deepEqual(left1, infterm) && left1neg == infneg))
                  && leftop.value == "∨")) {
                    valid = false;
                }
              }
              else if (rightop != null) {
                if(!(((deepEqual(right1, leftterm) && right1neg != leftneg && deepEqual(right2, infterm) && right2neg == infneg)
                  || (deepEqual(right2, leftterm) && right2neg != leftneg && deepEqual(right1, infterm) && right1neg == infneg))
                  && rightop.value == "∨")) {
                    valid = false;
                }
              }
              else {
                valid = false;
              }
              break;
          case "ad":
              if (childData.length != 1) {
                valid = false;
                break;
              }

              if (infop != null) {
                if(!(((deepEqual(leftterm, inf1) && leftneg == inf1neg) || (deepEqual(leftterm, inf2) && leftneg == inf2neg)) && infop.value == "∨")) {
                  valid = false;
                }
              } else {
                valid = false;
                break;
              }
              break;

          case "si":
              if (childData.length != 1) {
                valid = false;
                break;
              }

              if (leftop != null) {
                if(!(((deepEqual(left1, infterm) && left1neg == infneg) || (deepEqual(left2, infterm) && left2neg == infneg)) && leftop.value == "∧")) {
                  valid = false;
                }
              } else {
                valid = false;
                break;
              }
              break;

          case "cj":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if (infop != null) {
                if(!(((deepEqual(leftterm, inf1) && deepEqual(rightterm, inf2) && leftneg == inf1neg && rightneg == inf2neg)
                  || (deepEqual(rightterm, inf1) && deepEqual(leftterm, inf2) && rightneg == inf1neg && leftneg == inf2neg)) 
                  && infop.value == "∧")) {
                  valid = false;
                }
              } else {
                valid = false;
                break;
              }
              break;

          case "re":
              if (childData.length != 2) {
                valid = false;
                break;
              }

              if (infop != null && leftop != null && rightop != null) {
                if(!(((deepEqual(left1, right1) && left1neg != right1neg && deepEqual(left2, inf1) && deepEqual(right2, inf2) && left2neg == inf1neg && right2neg == inf2neg)
                  || (deepEqual(left1, right2) && left1neg != right2neg && deepEqual(left2, inf1) && deepEqual(right1, inf2) && left2neg == inf1neg && right1neg == inf2neg)
                  || (deepEqual(left1, right1) && left1neg != right1neg && deepEqual(left2, inf2) && deepEqual(right2, inf1) && left2neg == inf2neg && right2neg == inf1neg)
                  || (deepEqual(left1, right2) && left1neg != right2neg && deepEqual(left2, inf2) && deepEqual(right1, inf1) && left2neg == inf2neg && right1neg == inf1neg)
                  || (deepEqual(left2, right1) && left2neg != right1neg && deepEqual(left1, inf1) && deepEqual(right2, inf2) && left1neg == inf1neg && right2neg == inf2neg)
                  || (deepEqual(left2, right2) && left2neg != right2neg && deepEqual(left1, inf1) && deepEqual(right1, inf2) && left1neg == inf1neg && right1neg == inf2neg)
                  || (deepEqual(left2, right1) && left2neg != right1neg && deepEqual(left1, inf2) && deepEqual(right2, inf1) && left1neg == inf2neg && right2neg == inf1neg)
                  || (deepEqual(left2, right2) && left2neg != right2neg && deepEqual(left1, inf2) && deepEqual(right1, inf1) && left1neg == inf2neg && right1neg == inf1neg)) 
                  && infop.value == "∨" && leftop.value == "∨" && rightop.value == "∨")) {
                  valid = false;
                }
              } else {
                valid = false;
                break;
              }
              break;
      }
    }
  }
  if(!valid) {
      document.getElementById('li' + id).getElementsByTagName( 'div' )[0].classList.add("invalid");
  } else {
      document.getElementById('li' + id).getElementsByTagName( 'div' )[0].classList.remove("invalid");
  }
}

// verifier end

var tree = new Tree("");
var rules = {};
rules["xx"] = "- select inference rule -";
rules["mp"] = "Modus ponens";
rules["mt"] = "Modus tollens";
rules["co"] = "Commutative";
rules["bi"] = "Law of bicond. propositions";
rules["tr"] = "Transposition";
rules["hs"] = "Hypothetical syllogism";
rules["mi"] = "Material implication";
rules["ds"] = "Disjunctive syllogism";
rules["ad"] = "Addition";
rules["si"] = "Simplification";
rules["cj"] = "Conjuction";
rules["re"] = "Resolution";

function Node(id, data) {
    this.id = id;
    this.data = data;
    this.children = [];
    this.rule = null;
}
 
function Tree(data) {
    var node = new Node("1", data);
    this._root = node;
}

Tree.prototype.add = function(id, toId) {
    var node = new Node(id, "");
    var parent = tree._root;
    for (var i = 0; i < (toId.length-1)/2; i++) {
        parent = parent.children[toId.charAt((i+1)*2)-1];
    }
    parent.children.push(node);
  };

Tree.prototype.remove = function(id) {
    var parent = tree._root;
    for (var i = 0; i < (id.length-3)/2; i++) {
        parent = parent.children[id.charAt((i+1)*2)-1];
    }
    parent.children.splice(id.charAt((i+1)*2)-1, 1);
}

Tree.prototype.update = function(id, data, reading) {
    var parent = tree._root;
    for (var i = 0; i < (id.length-1)/2; i++) {
        parent = parent.children[id.charAt((i+1)*2)-1];
    }
    parent.data = data;
    if(!reading) {checkRule(id, parent.rule, data, parent.children);}
    if (id.length > 2) {
        var infId = id.slice(0, -2);
        var inf = tree.get(infId);
        if(!reading) {checkRule(infId, inf.rule, inf.data, inf.children);}
    }
}

Tree.prototype.updateRule = function(id, rule) {
    var parent = tree._root;
    for (var i = 0; i < (id.length-1)/2; i++) {
        parent = parent.children[id.charAt((i+1)*2)-1];
    }
    parent.rule = rule;
}

Tree.prototype.get = function(id) {
    var parent = tree._root;
    for (var i = 0; i < (id.length-1)/2; i++) {
        parent = parent.children[id.charAt((i+1)*2)-1];
    }
    return parent;
}

function update(id) {
  var data = document.getElementById('contents' + id).value;
  tree.update(id, data, false);
}

function updateWithData(id, data) {
  tree.update(id, data, true);
}

function readFile(f) {
    var file = f.target.files[0];
    var reader = new FileReader();
    reader.onload = function(f) {
        var contents = f.target.result;
        var treeread = JSON.parse(contents);
        tree = new Tree(treeread._root.data);
        displayContents(treeread);
    };
    reader.readAsText(file);
}

function displayContents(c) {
    var p = document.getElementById('parent');
    p.innerHTML = '<ul id="ul1"><li id="li1"><div class="flipback"><input type="button" value="&and;" onclick="and(\'1\')" />'
      + '​<input type="button" value="&or;" onclick="or(\'1\')" />​<input type="button" value="&rarr;" onclick="rarr(\'1\')" />'
      + '​<input type="button" value="&harr;" onclick="harr(\'1\')" />​<input type="button" value="&not;" onclick="not(\'1\')" />'
      + '​<input type="button" value="add child" onclick="addChild(\'1\')" /><br /><select id="rules1" onChange="changeRule(1, value)">'
      + '</select><br /><textarea id="contents1" oninput="update(\'1\')"></textarea></div></li></ul>';
    updateWithData(1, c._root.data);
    var p = document.getElementById('contents1');
    p.value = c._root.data;
    addRulesSelect(1);
    selectRuleFromDropdown(1, c._root.rule);
    tree.updateRule(1, c._root.rule);
    iterThroughChildren(1, c._root.children);
}

function iterThroughChildren(id, array) {
    for (var i = 0; i < array.length; i++) {
      addChild(id);
      updateWithData(array[i].id, array[i].data);
      var p = document.getElementById('contents' + array[i].id);
      p.value = array[i].data;
      addRulesSelect(array[i].id);
      selectRuleFromDropdown(array[i].id, array[i].rule);
      tree.updateRule(array[i].id, array[i].rule);
      iterThroughChildren(array[i].id, array[i].children);
    }
}

function selectRuleFromDropdown(id, rule) {
  var sel = document.getElementById('rules' + id);
  for (var i = 0; i < sel.options.length; i++) {
    if (sel.options[i].value == rule) {
        sel.options[i].selected = true;
        return;
    }
  }
}

function saveFile() {
    var contents = JSON.stringify(tree);
    var file = new Blob([contents], {type: "text/plain"});
    var a = document.createElement("a"),
        url = URL.createObjectURL(file);
    a.href = url;
    a.download = "proof.txt";
    document.body.appendChild(a);
    a.click();
    setTimeout(function() {
        document.body.removeChild(a);
        window.URL.revokeObjectURL(url);  
    }, 0); 
}

function and(id) {
    var p = document.getElementById('contents' + id);
    var start = p.selectionStart;
    var end = p.selectionEnd;
    var val = p.value;
    var before = val.substring(0, start);
    var after  = val.substring(end, val.length);
    p.value = (before + '\u2227' + after);
    update(id);
}

function or(id) {
  var p = document.getElementById('contents' + id);
  var start = p.selectionStart;
  var end = p.selectionEnd;
  var val = p.value;
  var before = val.substring(0, start);
  var after  = val.substring(end, val.length);
  p.value = (before + '\u2228' + after);
  update(id);
}

function rarr(id) {
  var p = document.getElementById('contents' + id);
  var start = p.selectionStart;
  var end = p.selectionEnd;
  var val = p.value;
  var before = val.substring(0, start);
  var after  = val.substring(end, val.length);
  p.value = (before + '\u2192' + after);
  update(id);
}

function harr(id) {
  var p = document.getElementById('contents' + id);
  var start = p.selectionStart;
  var end = p.selectionEnd;
  var val = p.value;
  var before = val.substring(0, start);
  var after  = val.substring(end, val.length);
  p.value = (before + '\u2194' + after);
  update(id);
}

function not(id) {
  var p = document.getElementById('contents' + id);
  var start = p.selectionStart;
  var end = p.selectionEnd;
  var val = p.value;
  var before = val.substring(0, start);
  var after  = val.substring(end, val.length);
  p.value = (before + '\u00ac' + after);
  update(id);
}

function addChild(id) {
    var newid = id + '-' + 1;
    var newliid = newid;
    var newul = document.getElementById('ul' + newid);
    if (newul === null) {
        newul = document.createElement('ul');
        newul.id = 'ul' + newid;
    }
    var newli = document.getElementById('li' + newliid);
    var i = 2;
    while (true) {
        if (newli === null) {
            newli = document.createElement('li');
            break;
        } else {
            newliid = id + '-' + i;
            newli = document.getElementById('li' + newliid);
            i++;
        }
    }
    newli.id = 'li' + newliid;
    newul.appendChild(newli);
    var newel = '<div class="flipback"><input type="button" value="&and;" onclick="and(\'' +
        newliid + '\')" />​<input type="button" value="&or;" onclick="or(\'' +
        newliid + '\')" />​<input type="button" value="&rarr;" onclick="rarr(\'' +
        newliid + '\')" />​<input type="button" value="&harr;" onclick="harr(\'' +
        newliid + '\')" />​<input type="button" value="&not;" onclick="not(\'' +
        newliid + '\')" />​<input type="button" value="add child" onclick="addChild(\'' +
        newliid + '\')" /><input type="button" value="X" onclick="remove(\'' +
        newliid + '\')" /><br /><select id="rules' +
        newliid + '" onChange="changeRule(\'' +
        newliid + '\', value)"></select><br /><textarea id="contents' +
        newliid + '" oninput="update(\'' +
        newliid + '\')"></textarea></div>';
    newli.innerHTML = newel;
    var oldliid = 'li' + id;
    document.getElementById(oldliid).appendChild(newul);
    addRulesSelect(newliid);
    var newnode = new Node(newliid, "");
    tree.add(newliid, id);
}

function changeRule(id, option) {
    var childrenNumber = tree.get(id).children.length;
    var i = 2;
    if (option == "as" || option == "co" || option == "ex" || option == "tr"
        || option == "mi" || option == "ad" || option == "si" || option == "dn") {
      i = 1;
    }
    for (i; i > childrenNumber; i--) {
        addChild(id);
    }
    tree.updateRule(id, option);
}

function remove(id) {
    document.getElementById('li' + id).remove();
    var oldulid = 'ul' + id.substring(0, id.length-2) + '-1';
    if(document.getElementById(oldulid).childElementCount == 0) {
        document.getElementById(oldulid).remove();
    }
    tree.remove(id);
}

function addRulesSelect(id) {
    var sel = document.getElementById('rules' + id);
    for(var key in rules) {
        var name = rules[key];
        var opt = document.createElement('option');
        opt.innerHTML = name;
        opt.value = key;
        sel.appendChild(opt);
    }
}



window.onload = function() {
    document.getElementById('openfile').addEventListener('change', readFile, false);
    addRulesSelect(1);
}